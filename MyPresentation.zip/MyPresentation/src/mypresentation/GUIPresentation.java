package mypresentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GUIPresentation extends JFrame{

    private JButton myExpectations, myPhoto, myHobby;
    private Title title;
    private JPanel containerButtons, containerImage;

    private Listener listener;
    public GUIPresentation(){
        initGUI();
        this.setTitle("My Presentation");
        this.setSize(600, 400);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //public GUIPresentation JButton{


       // }


    }

    private void initGUI() {
        title = new Title("A presentation about me", Color.BLACK);
        myPhoto = new JButton("This is me");
        myHobby = new JButton("This is my hobby");
        myExpectations = new JButton("This is my expectations");

        containerButtons = new JPanel();
        containerImage = new JPanel();
        listener = new Listener();

        containerButtons.add(myExpectations);
        containerButtons.add(myHobby);
        containerButtons.add(myPhoto);

        myPhoto.addActionListener(listener);
        myHobby.addActionListener(listener);
        myExpectations.addActionListener(listener);

        this.add(title, BorderLayout.NORTH);
        this.add(containerButtons, BorderLayout.SOUTH);

    }


    public static void main(String[]args){
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                GUIPresentation myGui = new GUIPresentation();
            }
        });
    }
    private class Listener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null,"Pressed button");
        }
    }

}
